import subprocess,os,json,datetime,pathlib
root=pathlib.Path('/workspace/work/run026/candidate');out=pathlib.Path('/workspace/work/run026/final/gates');out.mkdir(parents=True,exist_ok=True)
env=dict(os.environ);env['PATH']='/workspace/work/run026/bin:'+env['PATH'];env['npm_config_cache']='/workspace/work/run026/cache/npm';env['npm_config_devdir']='/workspace/work/run026/cache/node-gyp'
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
sha=git('rev-parse','HEAD');assert sha=='e11579950ef7ed20e4b6eeee88f9c3597c1f074b';assert git('status','--porcelain')==''
results={'sha':sha,'baseline':'dd968ba05e579461962bbcced0e9cae3cd4c3d23','commands':[]}
commands=['yarn install --frozen-lockfile --non-interactive','yarn --cwd workspace-server install --frozen-lockfile --non-interactive','yarn compile','yarn build','yarn test:sc','yarn test:library','yarn --cwd workspace-server compile','yarn --cwd workspace-server test']
for i,cmd in enumerate(commands):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (out/f'{i+1:02d}.log').open('w') as f:r=subprocess.run(cmd,cwd=root,env=env,shell=True,stdout=f,stderr=subprocess.STDOUT)
 results['commands'].append({'command':cmd,'exitCode':r.returncode,'startedAt':start,'finishedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'log':f'{i+1:02d}.log'})
 (out/'gate-results.json').write_text(json.dumps(results,indent=2))
 print(cmd,'=>',r.returncode,flush=True)
 assert git('rev-parse','HEAD')==sha
 assert git('status','--porcelain')==''
results['cleanWorkingTree']=True;results['allExitZero']=all(x['exitCode']==0 for x in results['commands']);(out/'gate-results.json').write_text(json.dumps(results,indent=2))
raise SystemExit(0 if results['allExitZero'] else 1)
