const assert=require('node:assert/strict'),fs=require('node:fs/promises'),path=require('node:path'),{execFileSync}=require('node:child_process'),{createHash}=require('node:crypto');
const {chromium}=require('/workspace/.rc-qa-tools/node_modules/playwright-core');
const sha=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),output='/workspace/work/run026/final/additional-surfaces';
const results={sha,engine:'Chromium',contrast:[],audit:[],visuals:[],requests:[],errors:[],consoleErrors:[]};let page;
const pause=ms=>new Promise(r=>setTimeout(r,ms));
async function colors(scene,t,specs=[]){
 const data=await page.evaluate(({scene,t,specs})=>{
 const rgba=c=>{const a=c.match(/[\d.]+/g)?.map(Number)||[0,0,0,0];return [...a.slice(0,3),a.length>3?a[3]:1];};
 const blend=(a,b)=>a.slice(0,3).map((v,i)=>v*a[3]+b[i]*(1-a[3])).concat(1);
 const bg=el=>{if(!el)return [255,255,255,1];const c=rgba(getComputedStyle(el).backgroundColor);return c[3]===1?c:blend(c,bg(el.parentElement));};
 const lum=c=>c.slice(0,3).map(v=>{v/=255;return v<=.04045?v/12.92:((v+.055)/1.055)**2.4;}).reduce((a,v,i)=>a+v*[.2126,.7152,.0722][i],0);
 const ratio=(a,b)=>{const x=lum(a),y=lum(b);return (Math.max(x,y)+.05)/(Math.min(x,y)+.05);};
 const visible=e=>e.getClientRects().length&&getComputedStyle(e).visibility!=='hidden'&&e.getBoundingClientRect().width>0;
 const measurements=[];
 for(const spec of specs){const el=Array.from(document.querySelectorAll(spec.selector)).find(visible);if(!el){measurements.push({...spec,missing:true});continue;}const cs=getComputedStyle(el,spec.pseudo||null),background=spec.outside?bg(el.parentElement):bg(el),foreground=rgba(cs[spec.property||'color']);measurements.push({...spec,scene,theme:t,tag:el.tagName,text:el.textContent.slice(0,100),computed:{foreground:cs[spec.property||'color'],background,opacity:cs.opacity,outlineStyle:cs.outlineStyle,outlineWidth:cs.outlineWidth},ratio:ratio(blend(foreground,background),background)});}
 const audit=[];
 const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
 while(walker.nextNode()){const node=walker.currentNode,el=node.parentElement;if(!node.textContent.trim()||!visible(el)||['SCRIPT','STYLE','OPTION'].includes(el.tagName))continue;const cs=getComputedStyle(el),background=bg(el),foreground=rgba(cs.color),large=parseFloat(cs.fontSize)>=24||(parseFloat(cs.fontSize)>=18.66&&parseInt(cs.fontWeight)>=700),disabled=!!el.closest('[disabled],.ant-select-disabled,.ant-checkbox-disabled'),threshold=disabled||large?3:4.5;const value=ratio(blend(foreground,background),background);audit.push({text:node.textContent.trim().slice(0,90),tag:el.tagName,className:el.className,foreground:cs.color,background,ratio:value,threshold,pass:value>=threshold});}
 return {measurements,audit};
 },{scene,t,specs});
 results.contrast.push(...data.measurements);results.audit.push({scene,theme:t,measurements:data.audit});
 if(process.env.COLLECT_ONLY)return;
 for(const p of data.measurements){assert(!p.missing,`Missing contrast surface ${p.name}`);if(p.property==='outlineColor')assert.notEqual(p.computed.outlineStyle,'none',p.name+' absent focus outline');assert(p.ratio>=p.min,`${scene} ${t} ${p.name}: ${p.ratio} < ${p.min}`);}
 const failures=data.audit.filter(p=>!p.pass);assert.deepEqual(failures,[],`${scene} ${t} rendered text contrast`);
}
const text=(name,selector)=>({name,selector,min:4.5}), boundary=(name,selector,property='borderTopColor',outside=false)=>({name,selector,property,outside,min:3});
async function run(){
 await fs.mkdir(output,{recursive:true});const b=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});page=await b.newPage({viewport:{width:1440,height:1000},deviceScaleFactor:1});results.version=b.version();
 const api=async()=>{const r=await fetch('http://127.0.0.1:4312/api/v1/workspace/_qa/snapshot');assert(r.ok);return r.json();};const before=await api();
 page.on('pageerror',e=>results.errors.push(e.message));page.on('console',m=>{if(m.type()==='error')results.consoleErrors.push(m.text());});page.on('request',r=>{if(r.url().includes('/api/v1'))results.requests.push({url:r.url(),method:r.method(),body:r.postData()});});
 const capture=async(scene,specs)=>{for(const t of ['LIGHT','DARK']){const n=results.requests.length;await page.locator(`input[name="library-theme"][value="${t}"]`).evaluate(e=>e.click());await pause(400);assert.equal(await page.locator('html').getAttribute('data-yu3doh-library-theme'),t);assert.deepEqual(results.requests.slice(n),[]);await colors(scene,t,specs);const file=`Chromium-${scene}-${t}-${sha.slice(0,12)}.png`;await page.screenshot({path:path.join(output,file)});results.visuals.push(file);}console.log(scene+' PASS');};
 const closeModal=async()=>{await page.locator('.ant-modal:visible .ant-modal-footer').getByRole('button',{name:'Cancel',exact:true}).click();await page.locator('.ant-modal:visible').waitFor({state:'hidden'});await pause(350);};
 try{
 await page.goto('http://127.0.0.1:3002/ygocarder/library/');await page.locator('.library-card__open').first().click();await page.locator('.library-detail').waitFor();
 await page.getByRole('button',{name:'Sources / Provenance',exact:true}).click();await page.locator('.library-provenance').waitFor();await capture('Provenance',[text('provenance text','.library-provenance'),text('native source filter','.library-provenance select')]);
 await page.getByRole('button',{name:'Canonical',exact:true}).click();await page.getByRole('button',{name:'Review / Confirm STRUCTURE',exact:true}).click();await page.locator('.ant-modal:visible').waitFor();await pause(500);await capture('Review-Confirm',[text('review title','.ant-modal .ant-modal-title')]);await closeModal();
 await page.getByRole('button',{name:'Variants / Assets',exact:true}).click();await page.locator('.library-variant-card').waitFor();await capture('Ingest',[text('ingest text','.library-ingest'),text('Preferred badge','.ant-tag-gold')]);
 await page.getByRole('button',{name:'Rename Variant',exact:true}).click();await page.locator('.ant-modal:visible input').first().waitFor();await capture('Variant-Lifecycle',[text('lifecycle title','.ant-modal .ant-modal-title'),text('lifecycle input','.ant-modal input')]);await closeModal();
 await page.getByRole('button',{name:'Resolve Conflict',exact:true}).first().click();await page.locator('.library-resolution-fields select').first().waitFor();await capture('Asset-Resolution',[text('native resolution choice','.library-resolution-fields select'),boundary('native resolution boundary','.library-resolution-fields select'),text('resolution title','.ant-modal .ant-modal-title')]);await closeModal();
 const after=await api();assert.deepEqual(after,before);results.workspaceInvariance={before:createHash('sha256').update(JSON.stringify(before)).digest('hex'),after:createHash('sha256').update(JSON.stringify(after)).digest('hex')};assert.deepEqual(results.errors,[]);results.result='PASS';
 }finally{await fs.writeFile(path.join(output,'evidence.json'),JSON.stringify(results,null,2));await b.close();}
}
run().catch(e=>{console.error(e);process.exitCode=1;});
