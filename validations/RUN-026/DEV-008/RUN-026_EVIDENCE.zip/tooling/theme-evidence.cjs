const assert=require('node:assert/strict'), fs=require('node:fs/promises'), path=require('node:path'), {execFileSync}=require('node:child_process'), {createHash}=require('node:crypto');
const engine=process.env.ENGINE||'Chromium', output=process.env.YU3DOH_QA_OUTPUT;
if(!output)throw Error('YU3DOH_QA_OUTPUT required');
const sha=execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(), key='yu3doh.library.theme.v1', attr='data-yu3doh-library-theme';
const origin=process.env.YU3DOH_QA_ORIGIN||'http://127.0.0.1:3002', url=origin+'/ygocarder/library/', pause=ms=>new Promise(r=>setTimeout(r,ms));
const results={sha,engine,cases:[],proofs:{},contrast:[],audit:[],errors:[],consoleErrors:[],requests:[],responses:[],visuals:[]};
if(process.env.INHERIT_INITIAL){
 const prefix=require(process.env.INHERIT_INITIAL);assert.equal(prefix.sha,sha);assert.equal(prefix.engine,engine);
 const ids=['DT-B01','DT-B02','DT-B03','DT-B04','DT-B05','DT-B06','DT-B07','DT-B08','DT-B24'];
 results.cases=prefix.cases.filter(c=>ids.includes(c.id));assert.equal(results.cases.length,9);
 for(const id of ids)if(prefix.proofs[id])results.proofs[id]=prefix.proofs[id];
 results.contrast=prefix.contrast.filter(c=>c.scene==='temporary-status');results.audit=prefix.audit.filter(c=>c.scene==='temporary-status');
 results.proofs.initialEvidence={file:process.env.INHERIT_INITIAL,sha:prefix.sha,fixture:prefix.fixture.fixture,ids};
}
if(process.env.RESUME_EXTRA){const prefix=require(process.env.INHERIT_PREFIX);assert.equal(prefix.sha,sha);assert.equal(prefix.engine,engine);for(const k of ['cases','proofs','contrast','audit','errors','consoleErrors','requests','responses','visuals'])results[k]=prefix[k];assert.equal(results.cases.length,19);results.proofs.surfaceCheckpoint={file:process.env.INHERIT_PREFIX,sha,ids:prefix.cases.map(c=>c.id)};}
let browser, page, context;
const pass=(id,proof)=>{results.cases.push({id,result:'PASS'});if(proof)results.proofs[id]=proof;console.log(id+' PASS');};
async function init(config){
 const seed=config.seed;
 const key='yu3doh.library.theme.v1';
 if(!sessionStorage.getItem('__dtSeeded')){if(seed===null)localStorage.removeItem(key);else if(seed!==undefined)localStorage.setItem(key,seed);sessionStorage.setItem('__dtSeeded','1');}
 window.__themeWrites=[];window.__themeReads=[];window.__denyWrite=!!config.denyWrite;
 const get=Storage.prototype.getItem,set=Storage.prototype.setItem;
 Storage.prototype.getItem=function(k){if(k===key){window.__themeReads.push(k);if(config.denyRead)throw new DOMException('Read denied','SecurityError');}return get.call(this,k);};
 Storage.prototype.setItem=function(k,v){if(k===key){window.__themeWrites.push({key:k,value:v});if(window.__denyWrite)throw new DOMException('Write denied','QuotaExceededError');}return set.call(this,k,v);};
 window.__firstContent=[];
 const observer=new MutationObserver(()=>{const root=document.getElementById('library-root');if(root&&root.childNodes.length&&window.__firstContent.length===0){window.__firstContent.push({theme:document.documentElement.getAttribute('data-yu3doh-library-theme'),text:root.textContent.slice(0,100),background:getComputedStyle(document.body).backgroundColor});observer.disconnect();}});
 observer.observe(document,{childList:true,subtree:true});
}
async function fresh(config={seed:'DARK'}){
 if(context)await context.close();
 context=await browser[engine==='Firefox'?'createBrowserContext':'newContext'](engine==='Firefox'?{}:{viewport:{width:1440,height:1000},deviceScaleFactor:1});
 page=await context.newPage();
 if(engine==='Firefox'){await page.setViewport({width:1440,height:1000,deviceScaleFactor:1}).catch(e=>{if(!e.message.includes('setScreenOrientationOverride'))throw e;});await page.evaluateOnNewDocument(init,config);}
 else await page.addInitScript(init,config);
 page.on('pageerror',e=>results.errors.push(e.message));page.on('console',m=>{if(m.type()==='error')results.consoleErrors.push({text:m.text(),url:m.location().url});});
 page.on('request',r=>{if(r.url().includes('/api/v1/'))results.requests.push({url:r.url(),method:r.method(),body:(()=>{try{return r.postData();}catch{return 'body unavailable over Firefox BiDi';}})()});});
 page.on('response',async r=>{if(/\/api\/v1\/library\/cards\?/.test(r.url())&&r.ok())try{results.responses.push({url:r.url(),body:await r.json()});}catch{}});
 await page.goto(url);await settle();
}
async function settle(){await page.waitForFunction(()=>document.querySelectorAll('.library-card').length>0&&!document.querySelector('.library-results .ant-spin'));await pause(200);}
async function viewport(w,h){if(engine==='Firefox')await page.setViewport({width:w,height:h,deviceScaleFactor:1}).catch(e=>{if(!e.message.includes('setScreenOrientationOverride'))throw e;});else await page.setViewportSize({width:w,height:h});await pause(120);}
async function click(selector,index=0){const pt=await page.evaluate(({selector,index})=>{const el=document.querySelectorAll(selector)[index];if(!el)throw Error('Missing '+selector+' '+index);el.scrollIntoView({block:'center'});const r=el.getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height/2};},{selector,index});await page.mouse.click(pt.x,pt.y);await pause(350);}
async function textClick(selector,text){const index=await page.evaluate(({selector,text})=>Array.from(document.querySelectorAll(selector)).findIndex(el=>el.textContent.trim()===text),{selector,text});assert(index>=0,'Missing '+text);await click(selector,index);}
async function input(selector,value){await click(selector);await page.keyboard.down('Control');await page.keyboard.press('a');await page.keyboard.up('Control');await page.keyboard.type(value);await pause(650);}
async function theme(value,synthetic=false){const current=await page.evaluate(()=>document.documentElement.getAttribute('data-yu3doh-library-theme'));if(current!==value){if(synthetic)await page.evaluate(value=>document.querySelector(`input[name="library-theme"][value="${value}"]`).click(),value);else await click('.library-theme .ant-radio-button-wrapper',value==='LIGHT'?0:1);}await pause(130);assert.equal(await page.evaluate(()=>document.documentElement.getAttribute('data-yu3doh-library-theme')),value);}
async function shot(scene,t){await page.evaluate(()=>window.scrollTo(0,0));const file=`${engine}-${scene}-${t}-${sha.slice(0,12)}.png`;await page.screenshot({path:path.join(output,file),fullPage:scene==='V01'||scene==='V02'});results.visuals.push(file);}
async function dom(scene,t){const data=await page.evaluate(()=>({html:document.documentElement.outerHTML,aria:Array.from(document.querySelectorAll('[role],[aria-label],[aria-pressed],[aria-invalid],input')).map(el=>({tag:el.tagName,role:el.getAttribute('role'),label:el.getAttribute('aria-label'),pressed:el.getAttribute('aria-pressed'),checked:el.checked,invalid:el.getAttribute('aria-invalid'),value:el.value}))}));await fs.writeFile(path.join(output,`${engine}-${scene}-${t}-DOM.json`),JSON.stringify(data,null,2));}
async function snapshot(){return page.evaluate(()=>({mode:document.querySelector('input[name="library-results-view"]:checked')?.value,query:document.querySelector('.library-controls input')?.value,facets:Array.from(document.querySelectorAll('.library-controls .ant-select-selection-item')).map(e=>e.textContent),page:document.querySelector('.ant-pagination-item-active')?.textContent,pageSize:document.querySelector('.ant-pagination-options')?.textContent,selected:document.querySelector('[data-testid="batch-selection-count"]')?.textContent,hidden:document.querySelector('[data-testid="batch-hidden-count"]')?.textContent,items:Array.from(document.querySelectorAll('.library-card')).map(e=>({id:e.dataset.cardId,revision:e.dataset.revision,checked:e.querySelector('input')?.checked,text:e.innerText})),detail:document.querySelector('.library-detail__toolbar')?.innerText,detailOpen:!!document.querySelector('.ant-drawer-open'),selectedDetail:Array.from(document.querySelectorAll('.library-card--selected')).map(e=>e.dataset.cardId),editor:Array.from(document.querySelectorAll('.library-editor-form input,.library-editor-form textarea,.library-editor-form select')).map(e=>({value:e.value,checked:e.checked,disabled:e.disabled,invalid:e.getAttribute('aria-invalid')})),markers:Array.from(document.querySelectorAll('.library-link-markers button')).map(e=>({label:e.getAttribute('aria-label'),pressed:e.getAttribute('aria-pressed')})),saveDisabled:Array.from(document.querySelectorAll('.library-detail__actions button')).find(e=>e.textContent==='Save')?.disabled,validation:Array.from(document.querySelectorAll('.library-editor-form [role="alert"]')).map(e=>e.textContent)}));}
async function preserve(label,target,synthetic=false){const before=await snapshot(), start=results.requests.length;await theme(target,synthetic);const after=await snapshot();assert.deepEqual(after,before,label+' state changed');assert.deepEqual(results.requests.slice(start),[],label+' generated requests');results.proofs[label]={before,after,requests:results.requests.slice(start)};}
async function colors(scene,t,specs=[]){
 const data=await page.evaluate(({scene,t,specs})=>{
 const rgba=c=>{const a=c.match(/[\d.]+/g)?.map(Number)||[0,0,0,0];return [...a.slice(0,3),a.length>3?a[3]:1];};
 const blend=(a,b)=>a.slice(0,3).map((v,i)=>v*a[3]+b[i]*(1-a[3])).concat(1);
 const bg=el=>{if(!el)return [255,255,255,1];const c=rgba(getComputedStyle(el).backgroundColor);return c[3]===1?c:blend(c,bg(el.parentElement));};
 const lum=c=>c.slice(0,3).map(v=>{v/=255;return v<=.04045?v/12.92:((v+.055)/1.055)**2.4;}).reduce((a,v,i)=>a+v*[.2126,.7152,.0722][i],0);
 const ratio=(a,b)=>{const x=lum(a),y=lum(b);return (Math.max(x,y)+.05)/(Math.min(x,y)+.05);};
 const visible=e=>e.getClientRects().length&&getComputedStyle(e).visibility!=='hidden'&&e.getBoundingClientRect().width>0;
 const measurements=[];
 for(const spec of specs){const el=Array.from(document.querySelectorAll(spec.selector)).find(visible);if(!el){measurements.push({...spec,missing:true});continue;}const cs=getComputedStyle(el,spec.pseudo||null),background=spec.outside?bg(el.parentElement):bg(el),foreground=rgba(cs[spec.property||'color']);measurements.push({...spec,scene,theme:t,tag:el.tagName,text:el.textContent.slice(0,100),computed:{foreground:cs[spec.property||'color'],background,opacity:cs.opacity,outlineStyle:cs.outlineStyle,outlineWidth:cs.outlineWidth},ratio:ratio(blend(foreground,background),background)});}
 const audit=[];
 const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
 while(walker.nextNode()){const node=walker.currentNode,el=node.parentElement;if(!node.textContent.trim()||!visible(el)||['SCRIPT','STYLE','OPTION'].includes(el.tagName))continue;const cs=getComputedStyle(el),background=bg(el),foreground=rgba(cs.color),large=parseFloat(cs.fontSize)>=24||(parseFloat(cs.fontSize)>=18.66&&parseInt(cs.fontWeight)>=700),disabled=!!el.closest('[disabled],.ant-select-disabled,.ant-checkbox-disabled'),threshold=disabled||large?3:4.5;const value=ratio(blend(foreground,background),background);audit.push({text:node.textContent.trim().slice(0,90),tag:el.tagName,className:el.className,foreground:cs.color,background,ratio:value,threshold,pass:value>=threshold});}
 return {measurements,audit};
 },{scene,t,specs});
 results.contrast.push(...data.measurements);results.audit.push({scene,theme:t,measurements:data.audit});
 if(process.env.COLLECT_ONLY)return;
 for(const p of data.measurements){assert(!p.missing,`Missing contrast surface ${p.name}`);if(p.property==='outlineColor')assert.notEqual(p.computed.outlineStyle,'none',p.name+' absent focus outline');assert(p.ratio>=p.min,`${scene} ${t} ${p.name}: ${p.ratio} < ${p.min}`);}
 const failures=data.audit.filter(p=>!p.pass);assert.deepEqual(failures,[],`${scene} ${t} rendered text contrast`);
}
const text=(name,selector)=>({name,selector,min:4.5}), boundary=(name,selector,property='borderTopColor',outside=false)=>({name,selector,property,outside,min:3});
async function closeDetail(){await click('.ant-drawer-open .ant-drawer-close');await page.waitForFunction(()=>!document.querySelector('.ant-drawer-open'));await pause(350);}
async function main(){
 await fs.mkdir(output,{recursive:true});
 browser=engine==='Firefox'?await require('/workspace/work/run026/browser-tools/node_modules/puppeteer-core').launch({browser:'firefox',executablePath:'/workspace/work/run026/firefox/usr/lib/firefox-esr/firefox-esr',headless:true,userDataDir:path.join(output,'firefox-profile'),env:{...process.env,XDG_CACHE_HOME:'/workspace/work/run026/cache',XDG_CONFIG_HOME:'/workspace/work/run026/config',MOZ_DISABLE_CONTENT_SANDBOX:'1'}}):await require('/workspace/.rc-qa-tools/node_modules/playwright-core').chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
 results.version=await browser.version();
 const api=async suffix=>{const r=await fetch('http://127.0.0.1:4312/api/v1/workspace/_qa/'+suffix);assert(r.ok);return r.json();};
 results.fixture=await api('info');assert.equal(results.fixture.sha,sha);assert.equal(results.fixture.schema,8);assert.equal(results.fixture.manifest.workspace_format_version,1);
 const before=await api('snapshot');await fs.writeFile(path.join(output,'workspace-before.json'),JSON.stringify(before));
 try {
 if(process.env.RESUME_EXTRA){await fresh({seed:'DARK'});}else{
 if(!process.env.SKIP_INITIAL){
 for(const [id,seed,expected,denyRead] of [['DT-B01',null,'DARK'],['DT-B02','LIGHT','LIGHT'],['DT-B03','DARK','DARK'],['DT-B06',' Dark ','DARK'],['DT-B07','LIGHT','DARK',true]]){
  await fresh({seed,denyRead});const state=await page.evaluate(()=>({theme:document.documentElement.getAttribute('data-yu3doh-library-theme'),first:window.__firstContent,writes:window.__themeWrites,reads:window.__themeReads,checked:document.querySelector('input[name="library-theme"]:checked')?.value}));assert.equal(state.theme,expected);assert.equal(state.checked,expected);assert.equal(state.first[0].theme,expected);assert.deepEqual(state.writes,[]);assert.equal(state.reads.length,1);pass(id,{seed,denyRead,...state});
 }
 pass('DT-B24',{observations:['DT-B01','DT-B02','DT-B03','DT-B06','DT-B07'].map(id=>results.proofs[id])});
 for(const [id,seed,next] of [['DT-B04','LIGHT','DARK'],['DT-B05','DARK','LIGHT']]){
  await fresh({seed});await theme(next);assert.equal(await page.evaluate(key=>localStorage.getItem(key),key),next);await page.reload();await settle();assert.equal(await page.evaluate(()=>document.documentElement.getAttribute('data-yu3doh-library-theme')),next);pass(id,{seed,selected:next});
 }
 await fresh({seed:'DARK',denyWrite:true});await theme('LIGHT');assert.equal(await page.evaluate(()=>document.querySelector('[role="status"]').textContent),'Theme preference could not be saved; this selection is temporary.');assert.equal(await page.evaluate(key=>localStorage.getItem(key),key),'DARK');await colors('temporary-status','LIGHT',[text('temporary status','.library-theme__status')]);await page.evaluate(()=>window.__denyWrite=false);await theme('DARK');assert.equal(await page.evaluate(()=>document.querySelector('.library-theme__status')),null);pass('DT-B08',{writeFailure:'nonblocking',recovery:'status cleared after successful write'});
 }
 await fresh({seed:'DARK'});await input('.library-controls input','F04 Search');await click('.library-controls .ant-select',2);await textClick('.ant-select-item-option-content','F04 Broad');await settle();await click('.ant-pagination-item-2');await page.evaluate(id=>window.__expectedCard=id,results.fixture.cards[50].cardId);await page.waitForFunction(()=>document.querySelector('.library-card')?.dataset.cardId===window.__expectedCard);await settle();assert.equal((await snapshot()).page,'2');await preserve('DT-B09-filters-page','LIGHT');pass('DT-B09');
 await click('.library-card .ant-checkbox-wrapper');await click('.ant-pagination-item-1');await page.evaluate(id=>window.__expectedCard=id,results.fixture.cards[0].cardId);await page.waitForFunction(()=>document.querySelector('.library-card')?.dataset.cardId===window.__expectedCard);await settle();assert.match((await snapshot()).hidden,/1/);await preserve('DT-B10-hidden-batch','DARK');pass('DT-B10');
 await click('.library-card__open');await page.waitForFunction(()=>!!document.querySelector('.library-detail'));await preserve('DT-B11-open-detail','LIGHT',true);pass('DT-B11');
 await textClick('.library-detail__actions button','Edit');await input('.library-editor-form input:not([disabled])','25000001');assert.equal((await snapshot()).saveDisabled,false);await preserve('DT-B12-dirty','DARK',true);pass('DT-B12');
 for(const t of ['LIGHT','DARK']){
  await theme(t,true);await page.keyboard.press('Tab');await page.evaluate(()=>document.querySelector('.library-link-markers button').focus());
  await colors('V03',t,[text('drawer text','.ant-drawer-title'),text('input value','.library-editor-form input:not([disabled])'),boundary('input border','.library-editor-form input:not([disabled])'),{...text('disabled input','.library-editor-form input[disabled]'),min:3},text('marker unpressed','.library-link-markers button[aria-pressed="false"]'),text('marker pressed','.library-link-markers button[aria-pressed="true"]'),boundary('marker selected','.library-link-markers button[aria-pressed="true"]','borderTopColor',true),boundary('marker focus','.library-link-markers button','outlineColor',true)]);
  await shot('V03',t);await dom('V03',t);
 }
 await click('.ant-drawer-open .ant-drawer-close');await page.waitForFunction(()=>!!document.querySelector('.ant-modal-confirm'));
 for(const t of ['LIGHT','DARK']){await theme(t,true);await colors('V04-confirm',t,[text('confirm text','.ant-modal-confirm-content'),text('confirm title','.ant-modal-confirm-title')]);await shot('V04-confirm',t);await dom('V04-confirm',t);}
 await textClick('.ant-modal-confirm button','Cancel');await page.waitForFunction(()=>!document.querySelector('.ant-modal-confirm'));await textClick('.library-detail__actions button','Cancel');await closeDetail();
 for(const [id,mode] of [['DT-B13','Grid'],['DT-B14','List']]){
  await click(`input[name="library-results-view"][value="${mode.toUpperCase()}"]`);
  for(const t of ['LIGHT','DARK'])await preserve(`${id}-${t}`,t);
  pass(id);
 }
 for(const t of ['LIGHT','DARK']){
  await theme(t);await click('.library-controls .ant-select',1);await page.waitForFunction(()=>!!document.querySelector('.ant-select-dropdown:not(.ant-select-dropdown-hidden)'));
  await colors('V04-dropdown',t,[text('dropdown option','.ant-select-dropdown:not(.ant-select-dropdown-hidden) .ant-select-item-option-content')]);await shot('V04-dropdown',t);await dom('V04-dropdown',t);await page.keyboard.press('ArrowDown');await page.keyboard.press('Escape');await click('.library-header h1');
 }
 pass('DT-B15');pass('DT-B16');pass('DT-B17');
 // Reset browse and batch through reload without any domain mutation.
 await page.reload();await settle();await click('.library-card__open');await page.waitForFunction(()=>!!document.querySelector('.library-detail'));
 await textClick('.library-detail__sections button','External Sources');await page.waitForFunction(()=>Array.from(document.querySelectorAll('button')).some(e=>e.textContent.trim()==='Open stored retrieval'));
 await textClick('.library-external-sources button','Open stored retrieval');await page.waitForFunction(()=>!!document.querySelector('.library-external-sources pre'));
 for(const t of ['LIGHT','DARK']){await theme(t,true);await colors('V05',t,[text('raw evidence','.library-external-sources pre'),text('table header','.library-external-sources th'),text('table body','.library-external-sources td'),boundary('table separator','.library-external-sources td')]);await shot('V05',t);}
 await textClick('.library-detail__sections button','Variants / Assets');await page.waitForFunction(()=>!!document.querySelector('.library-variant-card'));
 for(const t of ['LIGHT','DARK']){await theme(t,true);await colors('V06',t,[text('variant text','.library-variant-card'),text('role slot','.library-role-slot')]);await shot('V06',t);}
 await closeDetail();
 for(const t of ['LIGHT','DARK']){await theme(t);await textClick('.library-header__actions button','Workspace');await page.waitForFunction(()=>!!document.querySelector('.workspace-management__metadata'));await colors('V07',t,[text('modal text','.ant-modal-title'),text('workspace metadata','.workspace-management__metadata')]);await shot('V07',t);await textClick('.ant-modal button','Close Workspace');await page.waitForFunction(()=>!Array.from(document.querySelectorAll('.ant-modal')).some(e=>e.getClientRects().length));}
 for(const t of ['DARK','LIGHT']){await theme(t);await textClick('.library-header__actions button','Needs Attention');await page.waitForFunction(()=>!!document.querySelector('.library-needs-attention'));await colors('needs-attention',t,[text('diagnostic panel','.library-needs-attention')]);await shot(t==='DARK'?'V09':'V10',t);await textClick('.library-needs-attention button','Close');}
 pass('DT-B18');
 for(const t of ['LIGHT','DARK']){
  await theme(t);await click('.library-card__open');await page.waitForFunction(()=>!!document.querySelector('.library-detail'));await closeDetail();
  for(const [scene,mode] of [['V01','LIST'],['V02','GRID']]){
   await click(`input[name="library-results-view"][value="${mode}"]`);await page.keyboard.press('Tab');await page.evaluate(()=>document.querySelector('.library-card__open').focus());
   await colors(scene,t,[text('shell text','.library-header h1'),text('muted header','.library-header p'),text('link','.library-card__open'),text('card readiness','.library-card__readiness'),text('input value','.library-controls input'),{...text('placeholder','.library-controls input'),pseudo:'::placeholder'},boundary('input border','.library-controls input'),boundary('card selected','.library-card--selected'),boundary('card selected outside','.library-card--selected','borderTopColor',true),boundary('detail focus','.library-card__open','outlineColor',true),text('success status','.ant-tag-green'),{...text('disabled action','.library-batch-toolbar button[disabled]'),min:3},boundary('disabled boundary','.library-batch-toolbar button[disabled]')]);
   await shot(scene,t);await dom(scene,t);
   for(const [w,h,cols] of [[1440,1000,3],[900,1000,2],[390,844,1]]){await viewport(w,h);const layout=await page.evaluate(()=>({width:innerWidth,dpr:devicePixelRatio,scroll:document.documentElement.scrollWidth,columns:getComputedStyle(document.querySelector('.library-results')).gridTemplateColumns.split(' ').length,theme:document.documentElement.getAttribute('data-yu3doh-library-theme')}));assert.equal(layout.dpr,1);assert(layout.scroll<=layout.width);assert.equal(layout.columns,mode==='GRID'?cols:1);(results.proofs.layouts||=[]).push({...layout,mode});if(w===390)await shot('V08-'+mode,t);}
   await viewport(1440,1000);
  }
  // Radio semantics, selected indication and native arrow-key selection.
  await page.keyboard.press('Tab');await page.evaluate(t=>document.querySelector(`input[name="library-theme"][value="${t}"]`).focus(),t);await colors('theme-focus',t,[boundary('theme focus','.library-theme .ant-radio-button-wrapper-checked','outlineColor',true),text('theme checked text','.library-theme .ant-radio-button-wrapper-checked')]);
  await page.keyboard.press('ArrowRight');assert.notEqual(await page.evaluate(()=>document.documentElement.getAttribute('data-yu3doh-library-theme')),t);
 }
 }
 // Additional frozen surfaces: validation, Batch, New Draft, all Preferred readiness states.
 await viewport(1440,1000);await page.reload();await settle();
 const validationId=await page.evaluate(()=>document.querySelectorAll('.library-card')[4].dataset.cardId);await click('.library-card__open',4);await page.evaluate(id=>window.__validationId=id,validationId);await page.waitForFunction(()=>document.querySelector('.library-detail__toolbar')?.textContent.includes(window.__validationId));
 await page.evaluate(()=>Array.from(document.querySelectorAll('.library-detail__actions button')).find(e=>e.textContent==='Edit').click());await page.waitForFunction(()=>!!document.querySelector('.library-editor-form'));await click('.library-editor-form .ant-select');await textClick('.ant-select-dropdown:not(.ant-select-dropdown-hidden) .ant-select-item-option-content','MAIN_DECK');await page.waitForFunction(()=>!!document.querySelector('input[aria-label="Level"]'));await input('input[aria-label="Level"]','13');
 await page.waitForFunction(()=>document.querySelector('input[aria-label="Level"]').getAttribute('aria-invalid')==='true');
 for(const t of ['LIGHT','DARK']){await theme(t,true);await colors('V03-validation',t,[text('validation error','.library-editor-form p[role="alert"]'),boundary('validation boundary','input[aria-invalid="true"]')]);await shot('V03-validation',t);}
 await textClick('.library-detail__actions button','Cancel');await closeDetail();
 await click('.library-card .ant-checkbox-wrapper');assert.match((await snapshot()).selected,/1/);await textClick('.library-batch-toolbar button','Batch Classification…');
 await page.waitForFunction(()=>!!document.querySelector('.library-batch-modal'));
 for(const t of ['LIGHT','DARK']){await theme(t,true);await colors('V07-batch',t,[text('Batch modal','.ant-modal-title'),text('Batch form','.library-batch-modal p')]);await shot('V07-batch',t);}
 await textClick('.ant-modal-footer button','Close');
 await page.waitForFunction(()=>!Array.from(document.querySelectorAll('.ant-modal')).some(e=>e.getClientRects().length));
 await textClick('.library-header__actions button','New Draft');await page.waitForFunction(()=>!!document.querySelector('.library-new-draft'));
 for(const t of ['LIGHT','DARK']){await theme(t,true);await colors('New-Draft',t,[text('New Draft modal','.ant-modal-title')]);await shot('New-Draft',t);}
 await textClick('.ant-modal-footer button','Cancel');
 await page.waitForFunction(()=>!Array.from(document.querySelectorAll('.ant-modal')).some(e=>e.getClientRects().length));
 results.proofs.preferredWarnings=[];
 for(let i=0;i<4;i++){
  const expectedId=await page.evaluate(i=>document.querySelectorAll('.library-card')[i].dataset.cardId,i);await click('.library-card__open',i);await page.evaluate(id=>window.__expectedDetail=id,expectedId);await page.waitForFunction(()=>document.querySelector('.library-detail__toolbar')?.textContent.includes(window.__expectedDetail));await textClick('.library-detail__sections button','Variants / Assets');await page.waitForFunction(()=>!!document.querySelector('.library-open-carder .ant-alert-info'));
  for(const t of ['LIGHT','DARK']){await theme(t,true);const warnings=await page.evaluate(()=>Array.from(document.querySelectorAll('.library-open-carder .ant-alert-warning')).map(e=>e.textContent));assert.equal(warnings.length,i===2?0:1);if(i===0)assert.match(warnings[0],/STANDARD and OVERFRAME unavailable/);if(i===1)assert.match(warnings[0],/OVERFRAME unavailable; STANDARD remains available/);if(i===3)assert.match(warnings[0],/STANDARD and OVERFRAME unavailable/);results.proofs.preferredWarnings.push({i,theme:t,warnings});await colors('Preferred-'+i,t,[text('Preferred info','.library-open-carder .ant-alert-info .ant-alert-message'),...(i===2?[]:[text('Preferred warning','.library-open-carder .ant-alert-warning .ant-alert-message')])]);await shot('Preferred-'+i,t);}
  await closeDetail();
 }
 // OVERFRAME-only READY cannot arise from the unchanged repository formula.
 // Render its unchanged warning as an explicitly synthetic presentation fixture.
 const warningText=execFileSync('node_modules/.bin/tsx',['-e',"import {preferredVariantWarning} from './src/library/preferred-variant-warning';console.log(preferredVariantWarning(false,true));"],{encoding:'utf8'}).trim();
 await page.evaluate(message=>{const el=document.createElement('section');el.id='qa-synthetic-warning';el.setAttribute('aria-label','Synthetic OVERFRAME-only warning presentation');el.className='ant-alert ant-alert-warning';const text=document.createElement('div');text.className='ant-alert-message';text.textContent=message;el.append(text);document.body.append(el);el.scrollIntoView();},warningText);
 for(const t of ['LIGHT','DARK']){await theme(t,true);await colors('Preferred-OVERFRAME-only-synthetic',t,[text('hypothetical Preferred warning','#qa-synthetic-warning .ant-alert-message')]);const file=`${engine}-Preferred-OVERFRAME-only-synthetic-${t}-${sha.slice(0,12)}.png`;await (await page.$('#qa-synthetic-warning')).screenshot({path:path.join(output,file)});results.visuals.push(file);}
 results.proofs.syntheticOverframeOnly={warningText,scope:'isolated rendered warning only; not a Workspace state',reason:'repository OVERFRAME READY implies STANDARD READY'};await page.evaluate(()=>document.getElementById('qa-synthetic-warning').remove());
 const pattern='**/api/v1/library/cards?*';
 let errorHandler;
 if(engine==='Firefox'){errorHandler=r=>/\/api\/v1\/library\/cards\?/.test(r.url())?r.respond({status:503,contentType:'application/json',body:JSON.stringify({code:'DT_QA_INJECTED',message:'Disposable QA transport failure'})}):r.continue();await page.setRequestInterception(true);page.on('request',errorHandler);}
 else await page.route(pattern,r=>r.fulfill({status:503,contentType:'application/json',body:JSON.stringify({code:'DT_QA_INJECTED',message:'Disposable QA transport failure'})}));
 await textClick('.library-batch-toolbar button','Refresh Library');await page.waitForFunction(()=>!!document.querySelector('.library-results .ant-alert-error'));
 for(const t of ['LIGHT','DARK']){await theme(t);await colors('error-state',t,[text('error alert','.library-results .ant-alert-error .ant-alert-message'),boundary('error boundary','.library-results .ant-alert-error')]);await shot('error-state',t);}
 if(engine==='Firefox'){page.off('request',errorHandler);await page.setRequestInterception(false);}else await page.unroute(pattern);
 await textClick('.library-results .ant-alert button','Retry');await settle();

 pass('DT-B23');
 // Prove all status categories on real operational surfaces: New Draft and existing loading/error cases are covered by F04.
 const networkStart=results.requests.length;await theme('DARK');await theme('LIGHT');assert.deepEqual(results.requests.slice(networkStart),[]);pass('DT-B19',{requests:results.requests.slice(networkStart)});
 const after=await api('snapshot');assert.deepEqual(after,before);await fs.writeFile(path.join(output,'workspace-after.json'),JSON.stringify(after));pass('DT-B20',{beforeHash:createHash('sha256').update(JSON.stringify(before)).digest('hex'),afterHash:createHash('sha256').update(JSON.stringify(after)).digest('hex')});
 const carder=await context.newPage();const reads=[];
 if(engine==='Firefox')await carder.evaluateOnNewDocument(()=>{window.__carderThemeReads=[];const old=Storage.prototype.getItem;Storage.prototype.getItem=function(k){if(k==='yu3doh.library.theme.v1')window.__carderThemeReads.push(k);return old.call(this,k);};});else await carder.addInitScript(()=>{window.__carderThemeReads=[];const old=Storage.prototype.getItem;Storage.prototype.getItem=function(k){if(k==='yu3doh.library.theme.v1')window.__carderThemeReads.push(k);return old.call(this,k);};});
 await carder.goto(origin+'/ygocarder/');await carder.waitForFunction(()=>document.getElementById('root')?.childNodes.length>0);await pause(500);const isolated=await carder.evaluate(()=>({theme:document.documentElement.getAttribute('data-yu3doh-library-theme'),reads:window.__carderThemeReads,hasLibraryStyles:Array.from(document.styleSheets).some(s=>{try{return Array.from(s.cssRules).some(r=>r.cssText.includes('data-yu3doh-library-theme'));}catch{return false;}})}));assert.deepEqual(isolated,{theme:null,reads:[],hasLibraryStyles:false});pass('DT-B21',isolated);await carder.screenshot({path:path.join(output,`${engine}-V11-Carder-${sha.slice(0,12)}.png`)});results.visuals.push(`${engine}-V11-Carder-${sha.slice(0,12)}.png`);await carder.close();
 for(const t of ['LIGHT','DARK']){await theme(t);if(engine==='Firefox'){const native=require('/workspace/work/run026/final/firefox-os.json');assert.equal(native.sha,sha);assert.equal(native.cases.length,6);assert(native.cases.every(c=>c.result==='PASS'));results.proofs.nativeOsPreferences=native;}else await page.emulateMedia({colorScheme:t==='LIGHT'?'dark':'light'});assert.equal(await page.evaluate(()=>document.documentElement.getAttribute('data-yu3doh-library-theme')),t);}
 pass('DT-B22');
 assert.deepEqual(results.errors,[]);if(!process.env.SKIP_INITIAL||process.env.INHERIT_INITIAL||process.env.RESUME_EXTRA)assert.equal(results.cases.length,24);
 }finally{await fs.writeFile(path.join(output,`${engine}-evidence.json`),JSON.stringify(results,null,2));await browser.close();}
}
main().catch(e=>{console.error(e);process.exitCode=1;});
